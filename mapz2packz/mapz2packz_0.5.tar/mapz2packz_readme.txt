Extract to your home directory then,

chmod +x ~/.gnome2/nautilus-scripts/Create\ New\ Map\ Package


read the usage notes in the top of this script:

gedit ~/.gnome2/nautilus-scripts/Create\ New\ Map\ Package
